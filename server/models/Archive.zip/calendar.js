// var mongoose = require('mongoose');
// var Schema = mongoose.Schema;
//
// var calendarSchema= new Schema({
//     team:{type:Schema.ObjectId},
//     date:Date,
//     event:String,
//     post:String,
//     description:String,
//     member:[{type:Schema.ObjectId}]
// });
//
//
// const ModelClass = mongoose.model('calendar', calendarSchema);
// module.exports = ModelClass;
//
//
//
